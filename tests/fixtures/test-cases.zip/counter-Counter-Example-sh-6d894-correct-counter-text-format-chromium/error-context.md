# Page snapshot

```yaml
- generic [ref=e3]:
  - heading "Counter Example" [level=1] [ref=e4]
  - generic [ref=e6]: "Counter: 0"
  - spinbutton [active] [ref=e8]: "99"
```